//
//  ViewController.swift
//  MealApp
//
//  Created by Pritesh Parekh on 7/3/17.
//  Copyright © 2017 Pritesh Parekh. All rights reserved.
//
import  os.log
import UIKit

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var save: UIBarButtonItem!
    @IBOutlet var tapImage: UITapGestureRecognizer!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var imageView: UIImageView!
    var meal : Meal?
  
    @IBOutlet weak var stack: stackController!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textField.becomeFirstResponder()
        
        textField.delegate  = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Button(_ sender: Any) {
        
        label.text = " Default Text"
    }
    
   
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        label.text = textField.text
    }
    
    
    
    
    @IBAction func tapImage(_ sender: UITapGestureRecognizer) {
    
   
        textField.resignFirstResponder()
       let imagePicker = UIImagePickerController()
        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self
        present(imagePicker, animated: true, completion: nil)
    }
        
    
    
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
       
        
        guard let putImage = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            fatalError(" Not found")
        }
        
        imageView.image = putImage
        
        dismiss(animated: true, completion: nil)
        
        
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        super.prepare(for: segue, sender: sender)
        
        // Configure the destination view controller only when the save button is pressed.
        guard let button = sender as? UIBarButtonItem, button === save else {
            os_log("The save button was not pressed, cancelling", log: OSLog.default, type: .debug)
            return
        }
        
        let name = textField.text ?? ""
        let photo = imageView.image
        let rating = stack.ratings
        
        // Set the meal to be passed to MealTableViewController after the unwind segue.
        meal = Meal(name: name, photo: photo, rating: rating)
    }
    
    
    
    
    
    
    
    
}

