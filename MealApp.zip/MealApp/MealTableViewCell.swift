//
//  MealTableViewCell.swift
//  MealApp
//
//  Created by Pritesh Parekh on 7/6/17.
//  Copyright © 2017 Pritesh Parekh. All rights reserved.
//

import UIKit

class MealTableViewCell: UITableViewCell {

    
    @IBOutlet weak var mealimage: UIImageView!
    @IBOutlet weak var star: stackController!
    @IBOutlet weak var label: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
