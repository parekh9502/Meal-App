//
//  stackController.swift
//  MealApp
//
//  Created by Pritesh Parekh on 7/4/17.
//  Copyright © 2017 Pritesh Parekh. All rights reserved.
//

import UIKit

@IBDesignable class stackController: UIStackView {
    
    @IBInspectable var starsize : CGSize = CGSize(width : 40.0, height: 40.0) {
        didSet {
            setupBtn()
        }
    }
    
    @IBInspectable var starcount : Int = 5 {
        didSet {
            setupBtn()
        }
    }
    
    private var ratingsBtn = [UIButton]()
    
    var ratings = 0 {
        didSet {
            updateSelstates()
        }
    }
    

    private func setupBtn() {
        
        for button in ratingsBtn {
            
            removeArrangedSubview(button)
            
            button.removeFromSuperview()
        }
        
        ratingsBtn.removeAll()
        
        
        
        
        let bundle = Bundle(for: type(of: self))
        
        let emptystar = UIImage(named : "empty", in : bundle, compatibleWith : self.traitCollection)
        
        let filledstar = UIImage(named: "filled", in : bundle, compatibleWith : self.traitCollection)
        
        let highstar = UIImage(named: "high" , in : bundle, compatibleWith : self.traitCollection)
        
        
        
        
        
        for index in 0..<starcount {
        
        let button = UIButton()
            
            
        button.setImage(emptystar, for: .normal)
            
        button.setImage(filledstar, for: .selected)
            
        button.setImage(highstar, for: .highlighted)
            
        button.setImage(highstar, for: [.selected, .highlighted])
            
            
        
        button.backgroundColor = UIColor.green
        
        button.translatesAutoresizingMaskIntoConstraints = false
        
        button.heightAnchor.constraint(equalToConstant: starsize.height).isActive = true
        
        button.widthAnchor.constraint(equalToConstant: starsize.width).isActive = true
        
        button.addTarget(self, action: #selector(stackController.btntapped(button:)), for: .touchUpInside)
        
        addArrangedSubview(button)
            
        ratingsBtn.append(button)
            
            
    }
        updateSelstates()
    }
    
    
   
    
    override init(frame: CGRect) {
        super .init(frame: frame)
        setupBtn()
    }
    
    required init(coder: NSCoder) {
        super .init(coder: coder)
        setupBtn()
    }


    
    
    
    func btntapped(button : UIButton) {
        
        guard let index = ratingsBtn.index(of: button) else {
            fatalError(" The button is not there in the array")
        }
        
        
        let selectedrating = index + 1
        
        
        if selectedrating == ratings {
            ratings = 0
        } else {
            ratings = selectedrating
            
        }
        
        let hintString: String?
        if ratings == index + 1 {
            hintString = "Tap to reset the rating to zero."
        } else {
            hintString = nil
        }
        
        // Calculate the value string
        let valueString: String
        switch (ratings) {
        case 0:
            valueString = "No rating set."
        case 1:
            valueString = "1 star set."
        default:
            valueString = "\(ratings) stars set."
        }
        
        // Assign the hint string and value string
        button.accessibilityHint = hintString
        button.accessibilityValue = valueString

        
    }
        private func updateSelstates() {
            
            for (ratings, index) in ratingsBtn.enumerated() {
                
               // button.isSelected = index < ratings
            }
            
        }
    
    
        
        
        
    

}
